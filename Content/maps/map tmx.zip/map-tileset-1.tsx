<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="map-tileset-1" tilewidth="32" tileheight="32" tilecount="192" columns="16">
 <image source="map-spritesheet-1.png" width="512" height="384"/>
</tileset>
